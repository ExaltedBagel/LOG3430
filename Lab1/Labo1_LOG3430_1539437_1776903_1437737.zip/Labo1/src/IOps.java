
public interface IOps {
	
	// Addition de 2 entiers avec d�tection d'erreurs
	public int add(int x, int y);
	
	// Soustraction de 2 entiers avec d�tection d'erreurs
	public int sub(int x, int y);
	
	// Multiplication de 2 entiers avec d�tection d'erreurs
	public int mult(int x, int y);
	
	// Division enti�re de 2 entiers avec d�tection d'erreurs
	public int div(int x, int y);
}
