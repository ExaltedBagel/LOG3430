package home;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 SuiteP suiteP=new SuitePImpl();
	   
		 suiteP.build("div", 2, 3, 7);
	     
	}

}
