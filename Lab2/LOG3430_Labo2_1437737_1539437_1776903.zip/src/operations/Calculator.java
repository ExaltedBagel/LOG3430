package operations;

public interface Calculator {
	 int multiply(int a, int b);
	 int divide(int a, int b);
	 int add(int a, int b);
	 int substract(int a, int b);
}

