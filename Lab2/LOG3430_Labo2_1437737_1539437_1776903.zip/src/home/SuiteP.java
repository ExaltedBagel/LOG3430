package home;

import pile.Pile;

public interface SuiteP {
	public Pile build(String op,int val1, int val2,int tailleMax);
}
